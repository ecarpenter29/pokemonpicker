from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

# Configure application
app = Flask(__name__)

@app.route("/")
def index():
    """Show Header asking for Pokemon to use"""
    return render_template("index.html")


@app.route("/error")
def error():
    """Give User an Error Message and Direct them to Some Popular Pokemon"""
    return render_template("buy.html")


@app.route("/paste", methods=["GET", "POST"])
def paste():
    """Display team in format to copy and paste into Pokemon Showdown"""
    return render_template("paste.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""

    # Check if it was called by post

    if request.method == "POST":

        # Check if they didn't enter anything
        if not request.form.get("symbol"):
            return apology("must submit stock", 400)

        # Store search request into a variable
        stock = lookup(str(request.form.get("symbol")))

        # don't need to check for special symbols because lookup() handles that

        # Check if they entered an invalid symbol
        if not stock:
            return apology("must enter a valid 4 digit stock symbol", 400)

        # Return template for the stock they searched for
        return render_template("quoted.html", name=stock['name'], symbol=stock['symbol'], price=stock['price'])

    # User submitted form by get
    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    # check if the user submitted the form by post
    if request.method == "POST":

        # check if the user entered a username, password, and confirmation
        username = request.form.get("username")
        if not username:
            return apology("must provide username", 400)
        password = request.form.get("password")
        if not password:
            return apology("must provide password", 400)
        confirmation = request.form.get("confirmation")
        if not confirmation:
            return apology("must provide confirmation", 400)

        # check if passwords match
        if password != confirmation:
            return apology("passwords must match", 400)

        # check if the username could cause issues with sql

        # List of characters that can cause issues with SQL queries
        problem_chars = ["\"", "\'", ";"]

        for char in problem_chars:
            if char in username:
                return apology("username cannot contain special characters", 400)

        # add user to database
        try:
            db.execute("INSERT INTO users (username, hash) VALUES (?, ?)",
                       username, generate_password_hash(password))
        except ValueError:
            return apology("username is already in use", 400)

        # redirect user to login form
        flash("Registered!")
        return redirect("/")

    # user submitted the form by get
    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""

    # get user's information
    user = db.execute("SELECT * FROM users WHERE id = ?;", session["user_id"])
    # get the symbols a current amount of shares of each stock the user owns
    # this is the same query as used in index\
    stocks = db.execute("SELECT stock, SUM(CASE WHEN sell = FALSE AND user_id = ? THEN shares ELSE 0 END) - "
                        "SUM(CASE WHEN sell = TRUE AND user_id = ? THEN shares ELSE 0 END) AS total_shares "
                        "FROM transactions GROUP BY stock HAVING total_shares > 0;", user[0]["id"], user[0]["id"])

    # check if user requested by get or post
    if request.method == "POST":

        # make sure user filled out a stock to buy, then add it to a variable
        if not request.form.get("symbol"):
            return apology("select stock to sell", 400)
        symbol = request.form.get("symbol")

        # make a list of symbols of stocks owned
        symbols = []
        for stock in stocks:
            symbols.append(stock["stock"])

        # check if the symbol inputted is somehow not in the list of symbols
        if symbol not in symbols:
            return apology("can only sell owned stocks", 400)

        # store requested stock into a variable
        requested_stock = db.execute("SELECT stock, SUM(CASE WHEN sell = FALSE AND user_id = ? THEN shares ELSE 0 END) - "
                                     "SUM(CASE WHEN sell = TRUE AND user_id = ? THEN shares ELSE 0 END) AS total_shares "
                                     "FROM transactions GROUP BY stock HAVING total_shares > 0 AND stock = ?;", user[0]["id"], user[0]["id"], symbol)

        # make sure the user entered how many stocks they want to buy, then enter it into a variable
        if not request.form.get("shares"):
            return apology("must submit how many stocks to buy", 400)
        shares = request.form.get("shares")

        # make sure the amount of shares is an integer
        try:
            shares = int(shares)
        except ValueError:
            return apology("must submit in integer amount to sell", 400)

        # make sure they tried to sell a positive amount of shares
        if shares < 1:
            return apology("must sumbit a positive amount to sell", 400)

        # make sure the user is not trying to sell more stocks than they have
        if requested_stock[0]["total_shares"] < shares:
            return apology("not enough stocks", 400)

        # store current time into a variable so there is no chance of crazy fluctuations
        current_time = datetime.datetime.now()
        cost = lookup(symbol)["price"]

        # add to transaction table
        db.execute("INSERT INTO transactions (user_id, stock, price, time, shares, sell) VALUES (?, ?, ?, ?, ?, ?);",
                   user[0]["id"], symbol, cost * shares, current_time, shares, True)

        # update cash user has, adding to the user's cash total
        db.execute("UPDATE users SET cash = ? WHERE id = ?",
                   user[0]["cash"] + (cost * shares), user[0]["id"])

        flash("Sold!")
        return redirect("/")

    # user requested via get
    else:
        return render_template("sell.html", stocks=stocks)
