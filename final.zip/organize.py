import sys
from cs50 import SQL

if len(sys.argv) != 3:
    print("Correct usage: (code_name).py (import).txt (database).db")
    sys.exit(1)

db = SQL("sqlite:///" + sys.argv[2])

with open(sys.argv[1], mode='r') as file:

    blank = 1
    # initialize dictionary for pokemon, the type of section it is, and the boolean for if data has been stored yet
    pokemon = {}
    section = ""
    stored = False
    first = True
    moves_stored = 0
    for row in file:
        data = row.replace('|', '').strip("+-\n ")
        if blank == 2:
            # if two lines have been skipped, you've gathered all the information about a pokemon
            if not first:
                # TODO make the sql query that'll add the information of that pokemon, then clear that information
                # check if there are 4 moves, if not, append the list to have values called None
                while len(pokemon["moves"]) != 4:
                    pokemon["moves"].append("Nothing")
                try:
                    db.execute("INSERT INTO pokemon (name, nature_id, hp, atk, def, spa, spd, spe, tera_id, ability_id, move_1_id, " \
                    "move_2_id, move_3_id, move_4_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", pokemon["name"], pokemon["nature"],
                    pokemon["stats"][0], pokemon["stats"][1], pokemon["stats"][2], pokemon["stats"][3], pokemon["stats"][4], pokemon["stats"][5],
                    pokemon["tera"], pokemon["ability"], pokemon["moves"][0], pokemon["moves"][1], pokemon["moves"][2], pokemon["moves"][3])
                except ValueError:
                    db.execute("INSERT INTO pokemon (name, nature_id, hp, atk, def, spa, spd, spe, tera_id, ability_id, move_1_id) " \
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", pokemon["name"], pokemon["nature"],
                    pokemon["stats"][0], pokemon["stats"][1], pokemon["stats"][2], pokemon["stats"][3], pokemon["stats"][4], pokemon["stats"][5],
                    pokemon["tera"], pokemon["ability"], pokemon["moves"][1])
                    pass
                for item in pokemon["items"]:
                    db.execute("INSERT INTO item_usage (pokemon_id, item_id, percent) VALUES (?, ?, ?)", db.execute("SELECT * FROM pokemon " \
                    "WHERE name = ?", pokemon["name"])[0]["pokemon_id"], item["item"], item["percent"])
            else:
                first = False
            # clear the information for the pokemon, and set the section back to name
            pokemon = {
                "name": "",
                "ability": "",
                "items": [],
                "nature": "",
                "stats": [],
                "moves": [],
                "tera": "",
            }
            moves_stored = 0
            section = "name"
        if not data:
            blank += 1
            stored = False
            section = ""
        else:
            blank = 0
            # TODO make flags for determining what kind of data it is, then clear that information
            if not section:
                # if there is data, but not a section, it must be a section header
                section = data
            elif section == "name":
                #TODO store name into name
                pokemon["name"] = data
            elif section == "Abilities":
                #TODO store top ability into ability
                ability = " ".join(data.split()[:-1])
                try:
                    db.execute("INSERT INTO abilities (ability_name) VALUES (?)", ability)
                except ValueError:
                    pass
                if not stored:
                    pokemon["ability"] = db.execute("SELECT * FROM abilities WHERE ability_name = ?", ability)[0]["ability_id"]
                    stored = True
            elif section == "Items":
                #TODO store items into list of dicitonaries with keys item and percent
                item = " ".join(data.split()[:-1])
                if item != "Other":
                    try:
                        db.execute("INSERT INTO items (item_name) VALUES (?)", item)
                    except ValueError:
                        pass
                    pokemon["items"].append({
                        "item": db.execute("SELECT * FROM items WHERE item_name = ?", item)[0]["item_id"],
                        "percent": data.split()[-1].replace("%", "")
                    })
            elif section == "Spreads":
                #TODO store all stats into stat dictionary plus nature
                # separate out the nature and stats
                spread = data.split()[0]
                if spread != "Other":
                    nature = spread.split(':')[0]
                    evs = spread.split(':')[1].split('/')
                # see if the nature has been added to the database yet
                try:
                    db.execute("INSERT INTO natures (nature_name) VALUES (?)", nature)
                except ValueError:
                    pass
                # if the pokemon hasn't had a spread added yet, add the information to it
                if not stored:
                    pokemon["nature"] = db.execute("SELECT * FROM natures WHERE nature_name = ?", nature)[0]["nature_id"]
                    pokemon["stats"] = evs
                    stored = True
            elif section == "Moves":
                #TODO store top 4 moves
                # store the move into a variable
                move = " ".join(data.split()[:-1])
                if move != "Other":
                    # try to add the move to the database
                    try:
                        db.execute("INSERT INTO moves (move_name) VALUES (?)", move)
                    except ValueError:
                        pass
                    # if 4 moves haven't been stored yet, add the id to the pokemon
                    if moves_stored != 4:
                        pokemon["moves"].append(db.execute("SELECT * FROM moves WHERE move_name = ?", move)[0]["move_id"])
                        moves_stored += 1
            elif section == "Tera Types":
                #TODO store top tera type
                # store type into a variable
                type = " ".join(data.split()[:-1])
                try:
                    db.execute("INSERT INTO types (type_name) VALUES (?)", type)
                except ValueError:
                    pass
                # if type hasn't been stored yet, add it to pokemon dictionary
                if not stored:
                    pokemon["tera"] = db.execute("SELECT * FROM types WHERE type_name = ?", type)[0]["type_id"]
                    stored = True
    while len(pokemon["moves"]) != 4:
        pokemon["moves"].append(db.execute("SELECT * FROM moves WHERE move_name = 'Nothing'")[0]["move_id"])
    try:
        db.execute("INSERT INTO pokemon (name, nature_id, hp, atk, def, spa, spd, spe, tera_id, ability_id, move_1_id, " \
        "move_2_id, move_3_id, move_4_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", pokemon["name"], pokemon["nature"],
        pokemon["stats"][0], pokemon["stats"][1], pokemon["stats"][2], pokemon["stats"][3], pokemon["stats"][4], pokemon["stats"][5],
        pokemon["tera"], pokemon["ability"], pokemon["moves"][0], pokemon["moves"][1], pokemon["moves"][2], pokemon["moves"][3])
        for item in pokemon["items"]:
            db.execute("INSERT INTO item_usage (pokemon_id, item_id, percent) VALUES (?, ?, ?)", db.execute("SELECT * FROM pokemon " \
            "WHERE name = ?", pokemon["name"])[0]["pokemon_id"], item["item"], item["percent"])
    except ValueError:
        pass
with open(sys.argv[1], mode='r') as file:
    blank = 1
    section = ""
    for row in file:
        #TODO iterate across file again, this time updating the teammates table
        data = row.replace('|', '').strip("+-\n ")
        if blank == 2:
            pokemon = data
        if not data:
            section = ""
            blank += 1
        else:
            blank = 0
            if not section:
                section = data
            elif section == "Teammates":
                teammate = "".join(data.split()[:-1])
                percent = data.split()[-1].replace("%", "")
                try:
                    db.execute("INSERT INTO teammates (pokemon_id, teammate_id, percent) VALUES (?, ?, ?)", db.execute("SELECT * FROM pokemon " \
                                "WHERE name = ?", pokemon)[0]["pokemon_id"], db.execute("SELECT * FROM pokemon WHERE name = ?", teammate)[0]["pokemon_id"],
                                percent)
                except IndexError:
                    pass

